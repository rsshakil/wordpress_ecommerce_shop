<?php

namespace Inc;

/**
 * Class Admin
 * @package KP\App
 */
class Admin {
    /**
     * Admin constructor.
     */
    public function __construct() {
        new Admin\Menu();
    }
}
